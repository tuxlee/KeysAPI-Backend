#!/bin/bash

# Ask how many times to run the command
read -p "How many times would you like to run the command? " times

output_file="matches.txt"
keyword="**HASBALANCE**"

# Example command to run (replace with your actual command)
# Assuming the command takes a page number as an argument
# command="./50 btc $SRANDOM$SRANDOM$SRANDOM$SRANDOM | grep -i $keyword >> $output_file"

# Loop through the sequence from start to end
for (( i=1; i<=times; i++ ))
do
    echo "Running command ./50 btc $RANDOM$RANDOM$SRANDOM$SRANDOM$SRANDOM$SRANDOM$SRANDOM$SRANDOM"
    eval "./50 btc $RANDOM$RANDOM$SRANDOM$SRANDOM$SRANDOM$SRANDOM$SRANDOM$SRANDOM | grep -i "$keyword" >> $output_file"
done

echo "Task completed."
